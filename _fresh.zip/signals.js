import{e as o}from"./chunk-BLU3JEWT.js";import"./chunk-V7IMYVGJ.js";import"./chunk-JG7V63GM.js";export{o as signal};
